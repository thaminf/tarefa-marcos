<?php
// Controller: Produto.php
class Produto extends CI_Controller
{

	// Método para inserir produto
	public function inserir()
	{
		$this->load->model('M_produto');
		$dados = json_decode(file_get_contents('php://input'), true);

		// Validações
		if (empty($dados['nome']) || empty($dados['preco']) || empty($dados['unidade_medida_id'])) {
			echo json_encode(['codigo' => 400, 'mensagem' => 'Todos os campos obrigatórios devem ser informados.']);
			return;
		}

		// Chamando o método inserir na Model e passando os dados recebidos
		$resultado = $this->M_produto->inserir($dados);
		echo json_encode($resultado);
	}

	// Método para consultar produtos
	public function consultar()
	{
		$this->load->model('M_produto');
		$filtros = $this->input->get(); // Recebe filtros enviados pela requisição GET

		// Chamando a Model para buscar os produtos com base nos filtros
		$resultado = $this->M_produto->consultar($filtros);
		echo json_encode($resultado);
	}

	// Método para alterar produto
	public function alterar()
	{
		$this->load->model('M_produto');
		$dados = json_decode(file_get_contents('php://input'), true);

		// Valida se o ID do produto foi enviado
		if (empty($dados['id'])) {
			echo json_encode(['codigo' => 400, 'mensagem' => 'O ID do produto deve ser informado.']);
			return;
		}

		// Chamando a Model para realizar a alteração
		$resultado = $this->M_produto->alterar($dados);
		echo json_encode($resultado);
	}

	// Método para desativar produto
	public function desativar()
	{
		$this->load->model('M_produto');
		$dados = json_decode(file_get_contents('php://input'), true);

		// Verifica se o ID do produto foi informado
		if (empty($dados['id'])) {
			echo json_encode(['codigo' => 400, 'mensagem' => 'O ID do produto deve ser informado.']);
			return;
		}

		// Chamando a Model para desativar o produto
		$resultado = $this->M_produto->desativar($dados['id']);
		echo json_encode($resultado);
	}
}
