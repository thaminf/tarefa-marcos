<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_produto extends CI_Model {

    //método para inserir produto
    public function inserir($dados) {
        //adicionando os dados recebidos a tabela produtos
        $this->db->insert('produtos', [
            'nome' => $dados['nome'],
            'preco' => $dados['preco'],
            'descricao' => $dados['descricao'] ?? null,
            'unidade_medida_id' => $dados['unidade_medida_id'],
            'status' => 'A', // ativo por padrão
        ]);

        if ($this->db->affected_rows() > 0) {
            //registra um log da inserção realizada
            $this->log('inserir', $this->db->insert_id(), $dados);
            return ['codigo' => 50, 'mensagem' => 'Produto inserido com sucesso.'];
        }
        return ['codigo' => 3, 'mensagem' => 'Erro ao inserir o produto.'];
    }

    //método para consultar produtos
    public function consultar($filtros) {
        //aplica os filtros recebidos, se houver
        if (!empty($filtros)) {
            $this->db->where($filtros);
        }

        //realiza a consulta na tabela produtos
        $query = $this->db->get('produtos');
        return $query->result_array();
    }

    //método para alterar produto
    public function alterar($dados) {
        //busca o produto pelo ID e atualiza os campos enviados
        $this->db->where('id', $dados['id']);
        $this->db->update('produtos', [
            'nome' => $dados['nome'] ?? null,
            'preco' => $dados['preco'] ?? null,
            'descricao' => $dados['descricao'] ?? null,
            'unidade_medida_id' => $dados['unidade_medida_id'] ?? null,
        ]);

        if ($this->db->affected_rows() > 0) {
            //registra um log da alteração realizada
            $this->log('alterar', $dados['id'], $dados);
            return ['codigo' => 80, 'mensagem' => 'Produto atualizado com sucesso.'];
        }
        return ['codigo' => 400, 'mensagem' => 'Erro ao atualizar o produto ou nenhuma alteração realizada.'];
    }

    //método para desativar produto
    public function desativar($id) {
        //atualiza o status do produto para "D" (desativado)
        $this->db->where('id', $id);
        $this->db->update('produtos', ['status' => 'D']); // D = Desativado

        if ($this->db->affected_rows() > 0) {
            //registra um log da desativação realizada
            $this->log('desativar', $id);
            return ['codigo' => 200, 'mensagem' => 'Produto desativado com sucesso.'];
        }
        return ['codigo' => 500, 'mensagem' => 'Erro ao desativar o produto ou produto já está desativado.'];
    }

    //método para registrar log
    private function log($acao, $id_produto, $dados = []) {
        //monta os dados do log
        $log = [
            'acao' => $acao,
            'id_produto' => $id_produto,
            'dados' => json_encode($dados),
            'data_hora' => date('Y-m-d H:i:s')
        ];
        //insere o log na tabela log_produtos
        $this->db->insert('log_produtos', $log);
    }
}

?>
