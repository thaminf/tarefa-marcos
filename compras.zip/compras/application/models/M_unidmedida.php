<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_unidmedida extends CI_Model {

    public function inserir($sigla, $descricao, $usuarioLogin){
        try{
            
            $sql = "insert into unid_medida (sigla, descricao, usucria)
                            values ('$sigla', '$descricao', '$usuarioLogin')";

            $this->db->query($sql);

            if($this->db->affected_rows() > 0){

                $this->load->model('M_log');

                $retorno_log = $this->M_log->inserirLog($usuarioLogin, $sql);

                if ($retorno_log['codigo'] == 1){
                    $dados = array('codigo' => 1,
                                'msg' => 'Unidade de Medida cadastrada corretamente');
                }else{
                    $dados = array('codigo' => 7,
                                'msg' => 'Houve algum problema no salvamento do log, porém, a Unidade de Medida foi inserida corretamente');
                }
            }else{
                $dados = array('codigo' => 6,
                            'msg' => 'Houve algum problema na inserção na tabela de unidade de medida');
            }
        }catch(Exception $e){
            $dados = array('codigo' => 00,
                            'msg' => 'ATENCAO: O seguinte erro aconteceu ->', $e->getMessage(), "\n");
        }

        return $dados;
    }

    public function consultar($codigo, $sigla, $descricao){
        try{
            $sql = "select * from unid_medida where estatus = '' ";

            if($codigo != '' && $codigo != '0'){
                $sql = $sql . " and cod_unidade = '$codigo' ";
            }

            if($sigla != ''){
                $sql = $sql . " and sigla = '$sigla' ";
            }

            if($descricao != ''){
                $sql = $sql . " and descricao like '%$descricao%' ";
            }

            $retorno = $this->db->query($sql);

            if($retorno->num_rows() > 0){
                $dados = array('codigo' => 1,
                            'msg' => 'Consulta realizada com sucesso',
                            'dados' => $retorno->result());
            }else{
                    $dados = array('codigo' => 6,
                                'msg' => 'Dados não encontrados');
            }
        }catch(Exception $e){
            $dados = array('codigo' => 00,
                            'msg' => 'ATENCAO: O seguinte erro aconteceu ->', $e->getMessage(), "\n");
        }

        return $dados;
    }

    public function alterar($codigo, $sigla, $descricao, $usuario) {
        try {
            //exercicio 3
            // Verificar se já existe uma unidade com a mesma sigla ou descrição
            $verifica_sql = "SELECT * FROM unid_medida WHERE (sigla = '$sigla' OR descricao = '$descricao') AND cod_unidade != $codigo";
            $query = $this->db->query($verifica_sql);
    
            if ($query->num_rows() > 0) {
                $dados = array('codigo' => 8, 'msg' => 'Já existe uma Unidade de Medida com a mesma sigla ou descrição');
                return $dados;
            }
    
            // Realizar a atualização caso não haja duplicatas
            if (trim($sigla) != '' && trim($descricao) != '') {
                $sql = "UPDATE unid_medida SET sigla = '$sigla', descricao = '$descricao' WHERE cod_unidade = $codigo";
            } elseif (trim($sigla) != '') {
                $sql = "UPDATE unid_medida SET sigla = '$sigla' WHERE cod_unidade = $codigo";
            } else {
                $sql = "UPDATE unid_medida SET descricao = '$descricao' WHERE cod_unidade = $codigo";
            }
    
            $this->db->query($sql);
    
            if ($this->db->affected_rows() > 0) {
                $this->load->model('M_log');
                $retorno_log = $this->M_log->inserirLog($usuario, $sql);
    
                if ($retorno_log['codigo'] == 1) {
                    $dados = array('codigo' => 1, 'msg' => 'Unidade de Medida atualizada corretamente');
                } else {
                    $dados = array('codigo' => 7, 'msg' => 'Houve algum problema no salvamento do log, porém, a Unidade de Medida foi alterada corretamente');
                }
            } else {
                $dados = array('codigo' => 6, 'msg' => 'Houve algum problema na alteração na tabela de unidade de medida');
            }
        } catch (Exception $e) {
            $dados = array('codigo' => 00, 'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ' . $e->getMessage());
        }
    
        return $dados;
    }

    public function desativar($codigo, $usuario){
        try{
            $sql = "select * from produtos where unid_medida = $codigo and estatus = '' ";

            $retorno = $this->db->query($sql);

            if($retorno->num_rows() > 0){
                $dados = array('codigo' => 3,
                            'msg' => 'Não podemos DESATIVAR, existem produtos associados a esta unidade de medida cadastrados.');
            }else{
                $sql2 = "update unid_medida set estatus = 'D' where cod_unidade = $codigo";

                $this->db->query($sql2);

                if($this->db->affected_rows() > 0){

                    $this->load->model('M_log');

                    $retorno_log = $this->M_log->inserirLog($usuario, $sql2);

                    if ($retorno_log['codigo'] == 1){
                        $dados = array('codigo' => 1,
                                    'msg' => 'Unidade de medida DESATIVADA corretamente');
                    }else{
                        $dados = array('codigo' => 8,
                                    'msg' => 'Houve algum problema no salvamento do log, porém, a Unidade de medida foi DESATIVADA corretamente');
                    }
                }else{
                    $dados = array('codigo' => 7,
                                'msg' => 'Houve algum problema na DESATIVAÇÃO da unidade de medida');
                }
            }
        }catch(Exception $e){
            $dados = array('codigo' => 00,
                            'msg' => 'ATENCAO: O seguinte erro aconteceu ->', $e->getMessage(), "\n");
        }

        return $dados;
    }
//exercicio1


    public function verificaUsuario($usuarioLogin) {
        $this->db->where('usuario', $usuarioLogin);
        $query = $this->db->get('usuarios');

        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    //exercicio2

    public function verificaSigla($sigla) {
        $this->db->where('sigla', $sigla);
        $query = $this->db->get('unid_medida'); 
       
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
?>